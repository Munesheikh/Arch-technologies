# Task 2: MNIST Digit Recognition

## Description
This project trains a neural network on the MNIST dataset to classify handwritten digits (0-9).

## Files
- Task2_MNIST_Digit_Recognition.ipynb : Jupyter Notebook with step-by-step explanation
- mnist_classifier.py : Python script
- Task2_Report.pdf : Project report
- README.md : Instructions

## How to Run
1. Install dependencies: `pip install tensorflow`
2. Run script: `python mnist_classifier.py`
