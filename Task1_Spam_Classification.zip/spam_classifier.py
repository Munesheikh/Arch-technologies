# Spam Email Classification - Student Style Implementation

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

# Step 1: Load dataset
# Example dataset CSV file should have columns: 'label' (spam/ham) and 'message'
data = pd.read_csv("spam.csv", encoding='latin-1')[['v1','v2']]
data.columns = ['label', 'message']

# Step 2: Convert labels into binary values (ham=0, spam=1)
data['label_num'] = data.label.map({'ham':0, 'spam':1})

# Step 3: Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    data['message'], data['label_num'], test_size=0.2, random_state=42)

# Step 4: Convert text to numerical features
vectorizer = CountVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# Step 5: Train model
model = MultinomialNB()
model.fit(X_train_vec, y_train)

# Step 6: Predict
y_pred = model.predict(X_test_vec)

# Step 7: Accuracy
acc = accuracy_score(y_test, y_pred)
print("Accuracy of Spam Classifier:", acc)
