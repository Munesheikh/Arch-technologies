# Task 1: Spam Email Classification

This project demonstrates a spam classifier using Naive Bayes algorithm.

## Files
- spam_classifier.py : Python script
- Task1_Spam_Classification.ipynb : Jupyter Notebook with explanations
- Task1_Report.pdf : Short report
- spam.csv : Dataset (not included, you need to add it)

## How to Run
1. Place `spam.csv` dataset in the same folder.
2. Run the script:
   ```
   python spam_classifier.py
   ```
3. Or open the Jupyter Notebook for step-by-step view.
